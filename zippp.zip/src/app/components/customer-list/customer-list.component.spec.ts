import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomerService } from "../../services/customer.service";
import { MatDialog, MatDialogModule, MatToolbarModule } from "@angular/material";
import { DialogService } from "../../services/dialog.service";
import { NotificationsService } from "../../services/notifications.service";
import { CustomerListComponent } from './customer-list.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MatIconModule } from '@angular/material/icon';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatSnackBar } from '@angular/material';
import { MatTableDataSource } from "@angular/material/table";
import { Customer } from "../../interfaces/customer";
import { of } from 'rxjs';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { CustomerDetailsComponent } from '../customer-details/customer-details.component';

describe('CustomerListComponent', () => {
  let component: CustomerListComponent;
  let fixture: ComponentFixture<CustomerListComponent>;
  let service: CustomerService;
  let serviceNotification: NotificationsService;
  let dialog: MatDialog;
  let serviceDialog: DialogService;
  let dataSource: MatTableDataSource<Customer>;
  let data;
  let details: Customer;
  let dialogMock = {
    filter: {}
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CustomerListComponent, ConfirmDialogComponent],
      imports: [HttpClientTestingModule, FormsModule, MatTableModule, MatDialogModule, MatToolbarModule, MatIconModule, BrowserAnimationsModule],
      providers: [{ provide: MatTableDataSource, useValue: dialogMock }, DialogService,{ provide: DialogService, entryComponents: {CustomerDetailsComponent,ConfirmDialogComponent} }, NotificationsService, CustomerService, MatSnackBar, MatTableDataSource],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    })
    fixture = TestBed.createComponent(CustomerListComponent);
    component = fixture.componentInstance;
    service = TestBed.get(CustomerService);
    serviceNotification = TestBed.get(NotificationsService);
    serviceDialog = TestBed.get(DialogService);
    dialog = TestBed.get(MatDialog);
    dataSource = TestBed.get(MatTableDataSource);
    details = <Customer>{};
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should execute ngOninit()', () => {
    component.ngOnInit();
    spyOn(component, 'getcustomer');
    expect(component.getcustomer).toBeDefined();
  });


  xit('should execute onSearchClear()', () => {
    component.onSearchClear();
    spyOn(component, 'onSearchClear');
    component.searchKey = "";
    spyOn(component, 'applyFilter');
    expect(component.applyFilter).toHaveBeenCalled();
    expect(component.onSearchClear()).toBeDefined();
  });


  // xit('should execute applyFilter()', () => {
  //   component.applyFilter();
  //   spyOn(component, 'applyFilter');
  //   let spy = spyOn(component.searchKey, 'trim').and.callThrough();
  //   let app = component.dataSource.filter;
  //   expect(spy).toHaveBeenCalled();
  //   expect(app).toMatch(component.searchKey.trim().toLowerCase());
  // });

  xit('should execute onCreate()', () => {
    // component.onCreate();
    // spyOn(component, 'onCreate');
    // expect(component.onCreate).toHaveBeenCalled();
    // spyOn(serviceDialog, 'opemForm');
    // expect(serviceDialog.opemForm).toHaveBeenCalled();
    // component.dialogservice.opemForm(0).afterClosed().subscribe(res => {
    //   spyOn(component, 'getcustomer');
    //   expect(component.getcustomer).toHaveBeenCalled();
    //   expect(component.getcustomer()).toBeDefined();
    // });
    const res: Customer[] = [];
    let app = component.dialogservice.openForm(0);
    spyOn(app, 'afterClosed').and.returnValue(of(res))


    component.onCreate();
    component.getcustomer();
    expect(component.onCreate).toBeDefined();
  });


  it('should execute getcustomer()', () => {
    const dataFromService: Customer[] = [];
    const response: Customer[] = [];
    let app = component.service;
    spyOn(app, 'getCustomerList').and.returnValue(of(response))
    component.getcustomer();
  });

  //**incomplete****** */
  it('should execute lower()', () => {
    component.lower(Object);
    expect(component).toBeTruthy();
  });


  //**incomplete****** */
  it('should execute delete()', () => {
    let cId = 0;
    component.delete(cId);
    expect(component).toBeTruthy();
  });


  //**incomplete****** */
  it('should execute onEdit()', () => {
    let cId = 0;
    component.onEdit(cId);
    spyOn(component,'onEdit');
    expect(component.onEdit).toHaveBeenCalledWith(cId);
    spyOn(serviceDialog,'openForm');
    expect(serviceDialog.openForm).toHaveBeenCalledWith(cId);
    let openforms = component.dialogservice.openForm(cId);
    spyOn(serviceDialog,'openForm');
    const dataFromService: Customer[] = [];
    const response: Customer[] = [];
    let app = component.service;
    spyOn(openforms, 'afterClosed').and.returnValue(of(response))
    component.getcustomer();
    expect(component).toBeTruthy();
  });
});


