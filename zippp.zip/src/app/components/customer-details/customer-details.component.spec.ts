import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { CustomerService } from "../../services/customer.service";
import { NotificationsService } from "../../services/notifications.service";
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatDialog, MAT_DIALOG_DATA, MatDialogModule, MatToolbarModule, MatDialogRef, MatSnackBar,MatSnackBarModule  } from "@angular/material";
import { CustomerDetailsComponent } from './customer-details.component';
import { OverlayContainer } from '@angular/cdk/overlay';
import { of } from 'rxjs';
import { Customer } from "../../interfaces/customer";
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
describe('CustomerDetailsComponent', () => {
  let component: CustomerDetailsComponent;
  let fixture: ComponentFixture<CustomerDetailsComponent>;
  let service: CustomerService;
  let serviceNotification: NotificationsService;
  let dialogref: MatDialogRef<CustomerDetailsComponent>;
  let overlayContainerElement: HTMLElement;
  let overlayContainer: OverlayContainer;
  let datalist: Customer;
  let formcid:any;
  let dialogMock = {
    close: () => { }
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CustomerDetailsComponent],
      imports: [HttpClientTestingModule, BrowserDynamicTestingModule, MatTableModule,MatSnackBarModule  ,MatDialogModule, MatToolbarModule, MatIconModule, BrowserAnimationsModule],
      providers: [CustomerService, NotificationsService, MatSnackBar, MatToolbarModule, { provide: MAT_DIALOG_DATA, useValue: {}, }, { provide: MatDialogRef, entryComponents: ConfirmDialogComponent, useValue: dialogMock }],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    })
    fixture = TestBed.createComponent(CustomerDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    dialogref = TestBed.get(MatDialogRef);
    service = TestBed.get(CustomerService);
    serviceNotification = TestBed.get(NotificationsService);
    datalist = <Customer>{};
    formcid=1;
  }));



  it('should create', () => {
    expect(component).toBeTruthy();
  });


  //**********incomplete */
  it('should execute ngOninit()', () => {
    const response: Customer[] = [];
    let app = component.service;
    spyOn(app, 'getCustomerList').and.returnValue(of(response))
    component.ngOnInit();
    let data = component.datalist;
    // expect(component.datalist).toEqual(response.customerList);
    expect(component.ngOnInit).toBeDefined();
  });

 //**********incomplete */
 it('should execute ngOninit(), if there is value for formcid', () => {
let formid= component.formcid=47;
   expect(component.formcid).toBe(formid);
  const response: Customer[] = [{
        cId : 47,
        firstname : "John",
        lastname :"Carter",
        date  : new Date(),
        email : "john.carter@diaspark.com",
        mobileNo : "7411536056",
        address : "Indore",
        city : "Indore",
        state : "MP",
        pin : "461223",
        country : "India"
      }];
  let app = component.service;
  spyOn(app, 'getCustomerbyid').and.returnValue(of(response))
  component.ngOnInit();
  let data = component.datalist;
  expect(component.datalist).toEqual(datalist[formid]);
  expect(component.ngOnInit).toBeDefined();
});


  //**********incomplete */
  it('should clear the form and reset via onClear()', () => {
    component.onClear();
    expect(component).toBeTruthy();
  });

  //**********incomplete */
  it('should close the dialog and reset via onClose()', () => {
    component.onClose();
    let spy = spyOn(component.dialogRef, 'close').and.callThrough();
    let spy1=spyOn(component.form,'reset').and.callThrough();
    let spy2=spyOn(component,'initializeFormGroup').and.callThrough();
    // expect(spy).toHaveBeenCalled();    
    expect(component).toBeTruthy();
  });

  //**********incomplete */
  xit('should populate the form and set the value', () => {
    const customers: Customer[] = [{
      cId : 47,
      firstname : "John",
      lastname :"Carter",
      date  : new Date(),
      email : "john.carter@diaspark.com",
      mobileNo : "7411536056",
      address : "Indore",
      city : "Indore",
      state : "MP",
      pin : "461223",
      country : "India"
    }];
    component.populateForm(customers);
    let spy = spyOn(component.form, 'setValue').and.callThrough();
    // expect(spy).toHaveBeenCalled();    
    expect(component).toBeTruthy();
  });


  //**********incomplete */
  it('should submit the form if it is valid', () => {
    component.onSubmit();
    component.notificationService.success("No changes");
    //  expect(component.form.valid).toBeTruthy();
    expect(component.form.pristine).toBe(true);
    let spy = spyOn(component.notificationService, 'success').and.callThrough();
    let spy1 = spyOn(component, 'onClose').and.callThrough();
    expect(spy).toBeDefined();
    expect(spy1).toBeDefined();
    expect(component).toBeTruthy();
  });

  //**********incomplete */
//   it('should execute onSubmit() when the form is valid and the id does not exist already in the list', () => {
//     component.onSubmit();
//     // component.notificationService.success("No changes");
//     // //  expect(component.form.valid).toBeTruthy();
//     // expect(component.form.pristine).toBe(true);
//     // let spy = spyOn(component.notificationService, 'success').and.callThrough();
//     // let spy1 = spyOn(component, 'onClose').and.callThrough();
//     // expect(spy).toBeDefined();
//     // expect(spy1).toBeDefined();
//     // expect(component).toBeTruthy();
//     // expect(component.form.valid).toBeTruthy(() => {
//       const formData = component.form.value;
//       expect(formData).toEqual(component.form.value);
//       expect(component.form.get('cId').value).not.toBeTruthy(() => {
//         const response: Customer[] = [];
//         let app = component.service;
//         spyOn(app, 'postCustomer').and.returnValue(of(response))
//         component.onSubmit();
//         let data = component.datalist;
//         // expect(component.datalist).toEqual(response.customerList);
//         expect(component.onSubmit).toBeDefined();

//       //});
//     });
//   });
});


